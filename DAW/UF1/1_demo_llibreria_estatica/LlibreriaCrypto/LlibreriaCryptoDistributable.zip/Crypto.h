#pragma once

void encripta(char *msg);
void desencripta(char *msg);