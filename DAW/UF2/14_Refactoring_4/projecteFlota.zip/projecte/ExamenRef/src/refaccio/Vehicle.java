package refaccio;

/**
 *
 */
public class Vehicle {
    
    public static final int COTXE=0;
    public static final int MOTO=1;
    public static final int CAMIO=2;
    
    public static final int GASOIL=0;
    public static final int GASOLINA_95=1;
    
    private int pes;
    private int tipus;
    private String matricula;
    private int tipusBenzina;
    private int capacitatDiposit;

    public Vehicle(int pes, int tipus, String matricula, int tipusBenzina, int capacitatDiposit) {
        this.pes = pes;
        this.tipus = tipus;
        this.matricula = matricula;
        this.tipusBenzina = tipusBenzina;
        this.capacitatDiposit = capacitatDiposit;
    }
    
    


    public int getPes() {
        return pes;
    }

    public int getTipus() {
        return tipus;
    }

    public String getMatricula() {
        return matricula;
    }

    public int getTipusBenzina() {
        return tipusBenzina;
    }

    public int getCapacitatDiposit() {
        return capacitatDiposit;
    }

    
}
