/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jmockit;

/**
 *
 * @author BERNAT
 */
public class Downloader {
 

    
    public String downloadXML( String url ) {
        throw new RuntimeException("Estem al Milà ! No tinc connexió a Internet :-P ! ");
    }
    
}
