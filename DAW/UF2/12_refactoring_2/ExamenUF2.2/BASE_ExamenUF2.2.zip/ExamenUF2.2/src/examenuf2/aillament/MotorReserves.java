
package examenuf2.aillament;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author bernat
 */
public class MotorReserves {

    
    public List<Integer> getLocalitzadors( int codiHotel) {
        throw new RuntimeException("No disponible sense connexi� a Internet");
    }
    
    public DadesHabitacio getInfoHabitacio( int codiLocalitzador, Date dataEntrada, Date dataSortida) {
        throw new RuntimeException("No disponible sense connexi� a Internet");
    }

    public String getNomHotel(int codiHotel) {
        throw new RuntimeException("No disponible sense connexi� a Internet");
    }
    
}
