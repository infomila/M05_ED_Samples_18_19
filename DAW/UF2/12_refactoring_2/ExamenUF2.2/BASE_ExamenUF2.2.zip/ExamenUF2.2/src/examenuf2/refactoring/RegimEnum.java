/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examenuf2.refactoring;

/**
 *
 * @author bernat
 */
public enum RegimEnum {
    NOMES_ALLOTJAMENT,
    ESMORCAR,
    MITJA_PENSIO,
    PENSIO_COMPLETA   
}
